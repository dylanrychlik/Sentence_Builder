package com.example.sentencebuilder

import android.net.Uri

//	Data class or model
data class WordUri(val word: String, val imageResId: Int)