package com.example.sentencebuilder

import androidx.appcompat.app.AppCompatActivity

class AddImageTest: AppCompatActivity()  {


}